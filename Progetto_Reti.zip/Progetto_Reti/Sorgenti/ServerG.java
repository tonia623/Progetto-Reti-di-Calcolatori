import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;
import java.net.ServerSocket;
import java.net.Socket;

public class ServerG {
    public static void main(String[] args) {

        try {
            ServerSocket serverSocketFromClientV2 = new ServerSocket(5006);

            //creo connessione con ServerV2
            Socket serverSocketFromServerV2 = new Socket("localhost",5004);

            while (true){
                Socket socketC2 = serverSocketFromClientV2.accept();

                // ricevo dati da ClientSV2
                DataInputStream dataInputStream = new DataInputStream(socketC2.getInputStream());
                String codiceTessera = dataInputStream.readUTF();
                System.out.println(String.format("Codice ricevuto dal ClientS2 %s",codiceTessera));

                // invio dati a ServerV2
                DataOutputStream dataOutputStream = new DataOutputStream(serverSocketFromServerV2.getOutputStream());
                dataOutputStream.writeUTF(codiceTessera);
                dataOutputStream.flush();
                System.out.println(String.format("Sto inviando %s a ServerV2...",codiceTessera));

                // ricevo esito da ServerV2
                DataInputStream dataInputStream1 = new DataInputStream(serverSocketFromServerV2.getInputStream());
                boolean esito = dataInputStream1.readBoolean();
                System.out.println("Ho ricevuto i dati dal ServerV2");

                // invio esito a ClientSV2
                DataOutputStream dataOutputStream1 = new DataOutputStream(socketC2.getOutputStream());
                dataOutputStream1.writeBoolean(esito);
                dataOutputStream1.flush();
                System.out.println(String.format("Sto mandando l'esito %s al ClientS2...",esito));

            }

        } catch (IOException e) {
            throw new RuntimeException(e);
        }
    }
}

