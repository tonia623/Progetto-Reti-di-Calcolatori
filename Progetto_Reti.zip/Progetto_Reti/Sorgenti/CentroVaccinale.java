import java.io.*;
import java.net.ServerSocket;
import java.net.Socket;
import java.time.LocalDate;

public class CentroVaccinale {
    public static void main(String[] args) {
        try {
            ServerSocket serverSocket = new ServerSocket(5002); // Porta del server

            //crea connessione con ServerV2
            Socket serverV2Socket = new Socket("localhost", 5003);

            while (true){
                Socket socket = serverSocket.accept();

                //ricevo dati da ClientUtente
                ObjectInputStream objectInputStream = new ObjectInputStream(socket.getInputStream());
                Greenpass greenpass = (Greenpass) objectInputStream.readObject();
                System.out.println(greenpass.getCodiceTessera());

                //invio dati a ServerV2
                DataOutputStream dataOutputStream = new DataOutputStream(serverV2Socket.getOutputStream());
                dataOutputStream.writeUTF(greenpass.getCodiceTessera());
                LocalDate dataScadenza = greenpass.getScadenza().plusMonths(6).plusDays(1);
                LocalDate now = LocalDate.now();
                if(now.isAfter(dataScadenza))
                    dataOutputStream.writeBoolean(false);
                else
                    dataOutputStream.writeBoolean(true);
                System.out.println("Sto inviando i dati al serverV2....");

                socket.close();

            }
        } catch (IOException | ClassNotFoundException e) {
            throw new RuntimeException(e);
        }
    }
}
