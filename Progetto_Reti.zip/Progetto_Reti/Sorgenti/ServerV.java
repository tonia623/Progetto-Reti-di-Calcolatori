import javax.swing.plaf.synth.SynthOptionPaneUI;
import java.io.*;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.Arrays;
import java.util.Collections;
import java.util.HashMap;
import java.util.Map;

public class ServerV {
    @SuppressWarnings("unchecked")
    public static void main(String[] args) {

        try {
            final Map<String, Boolean>[] greenPassValidi = new Map[]{new HashMap<>()};
            final Map<String, Boolean>[] greenPassScaduti = new Map[]{new HashMap<>()};

            ServerSocket serverSocketFromCentroVaccinale = new ServerSocket(5003);
            ServerSocket serverSocketFromServerG2 = new ServerSocket(5004);
            ServerSocket serverSocketFromClientT = new ServerSocket(5010);

            while (true) {
                // Accetta una connessione dal CentroVaccinale
                Socket socketCV = serverSocketFromCentroVaccinale.accept();
                Thread ThreadCentroVaccinale = new Thread(() -> {
                    while(true){
                        try {
                            // Ricevi dati da CentroVaccinale
                            DataInputStream dataInputStream = new DataInputStream(socketCV.getInputStream());
                            String tessera = dataInputStream.readUTF();
                            boolean validita = dataInputStream.readBoolean();
                            System.out.printf("%s, %s%n", tessera, validita);

                            if (validita) {
                                synchronized (SharedLock.lock){
                                    greenPassValidi[0].put(tessera, validita);
                                }
                            } else {
                                synchronized (SharedLock.lock){
                                    greenPassScaduti[0].put(tessera, validita);
                                }
                            }
                            System.out.println(Arrays.asList(greenPassValidi[0]) + "GREENPASS VALIDI");
                            System.out.println(Arrays.asList(greenPassScaduti[0]) +  "GREENPASS SCADUTI");

                        } catch (IOException e) {
                            e.getStackTrace();
                        }
                    }
                });

                ThreadCentroVaccinale.start();

                // Accetta una connessione dal ServerG2
                Socket socketG2 = serverSocketFromServerG2.accept();

                // Gestisci la connessione in un thread separato
                Thread ThreadServerG2 = new Thread(() -> {
                    while (true){
                        try {
                            // Ricevi dati da ServerG2
                            DataInputStream clientSinputStream = new DataInputStream(socketG2.getInputStream());
                            String tesseraClientS = clientSinputStream.readUTF();
                            System.out.printf("%s tessera ricevuta dal clientS%n", tesseraClientS);

                            // Invia dati al ServerG2
                            System.out.println(Collections.singletonList(greenPassValidi[0]).toString()+"GREENPASS VALIDI QUANDO RICEVO CHIAMATA DA CLIENTS");
                            boolean result = greenPassValidi[0].containsKey(tesseraClientS);
                            DataOutputStream dataOutputStream = new DataOutputStream(socketG2.getOutputStream());
                            dataOutputStream.writeBoolean(result);
                            dataOutputStream.flush();
                            System.out.println("Sto inviando l'esito al ServerG2...");
                        } catch (IOException e) {
                            e.getStackTrace();
                        }
                    }
                });

                ThreadServerG2.start();

                //accetta una connessione dal clientT
                Socket socketClientT = serverSocketFromClientT.accept();

                //gestisci connessione in un thread
                Thread threadClientT = new Thread(()->{
                    while (true){
                        try{
                            //invia liste greenpass a ClientT
                            ObjectOutputStream objectOutputStream = new ObjectOutputStream(socketClientT.getOutputStream());
                            objectOutputStream.writeObject(greenPassValidi[0]);
                            objectOutputStream.writeObject(greenPassScaduti[0]);
                            objectOutputStream.flush();
                            System.out.println("Sto inviando le liste al ClientT....");

                            //ricevo liste aggiornate da ClientT
                            ObjectInputStream objectInputStream = new ObjectInputStream(socketClientT.getInputStream());
                            Map<String,Boolean> newGreenPassValidi = (Map<String, Boolean>) objectInputStream.readObject();
                            Map<String,Boolean> newGreenPassScaduti = (Map<String, Boolean>) objectInputStream.readObject();
                            synchronized (SharedLock.lock){
                                greenPassValidi[0] = newGreenPassValidi;
                                greenPassScaduti[0] = newGreenPassScaduti;
                            }
                            System.out.println("Sto aggiornando le liste dei greenpass...");
                            System.out.println(Collections.singletonList(greenPassValidi[0]).toString()+"GREENPASS VALIDI AFTER CLIENTT");
                            System.out.println(Collections.singletonList(greenPassScaduti[0]).toString() + "GREENPASS SCADUTI AFTER CLIENTT");

                        } catch (IOException | ClassNotFoundException e) {
                            e.getStackTrace();
                        }
                    }
                });

                threadClientT.start();
            }
        } catch (IOException e) {
            throw new RuntimeException(e);
        }
    }

}