import java.io.DataOutputStream;
import java.io.IOException;
import java.io.ObjectOutputStream;
import java.net.Socket;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;

public class ClientUtente {
    public static void main(String[] args) {
        try {

            Socket socket = new Socket("localhost", 5002); // Connetti al CentroVaccinale

            DateTimeFormatter formatter = DateTimeFormatter.ofPattern("dd/MM/yyyy");
            LocalDate ultimoVaccino = LocalDate.parse(args[1],formatter);
            Greenpass greenpass = new Greenpass(args[0], ultimoVaccino);

            // invio oggetto greenpass al CentroVaccinale
            ObjectOutputStream objectOutputStream = new ObjectOutputStream(socket.getOutputStream());
            objectOutputStream.writeObject(greenpass);
            objectOutputStream.flush();

            socket.close();

        } catch (IOException e) {
            throw new RuntimeException(e);
        }
    }
}
