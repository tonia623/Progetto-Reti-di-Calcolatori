import java.io.Serializable;
import java.time.LocalDate;

public class Greenpass implements Serializable {
    private String codiceTessera;
    private LocalDate scadenza;

    public Greenpass(String codiceTessera, LocalDate scadenza) {
        this.codiceTessera = codiceTessera;
        this.scadenza = scadenza;
    }
    public Greenpass(String codiceTessera) {
        this.codiceTessera = codiceTessera;
    }

    public String getCodiceTessera() {
        return codiceTessera;
    }

    public LocalDate getScadenza() {
        return scadenza;
    }

}
