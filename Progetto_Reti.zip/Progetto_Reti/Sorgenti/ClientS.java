import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;
import java.net.Socket;

public class ClientS {
    public static void main(String[] args)  {

        try {

            Socket socket = new Socket("localhost", 5006); // Connetti al ServerG2

            // invio dati a ServerG2
            DataOutputStream dataOutputStream = new DataOutputStream(socket.getOutputStream());
            dataOutputStream.writeUTF(args[0]);
            dataOutputStream.flush();

            //ricevo risposta da ServerV2
            DataInputStream dataInputStream = new DataInputStream(socket.getInputStream());
            boolean validita = dataInputStream.readBoolean();
            System.out.println(String.format("Il greenpass è valido? : %s",validita));

            socket.close();

        } catch (IOException e) {
            throw new RuntimeException(e);
        }
    }
}
