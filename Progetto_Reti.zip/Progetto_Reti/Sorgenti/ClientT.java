import java.io.*;
import java.net.Socket;
import java.util.List;
import java.util.Map;

public class ClientT {
    @SuppressWarnings("unchecked")
    public static void main(String[] args)  {
        try {
            Socket socketServerV = new Socket("localhost",5010); // Connetti al ServerV

            //leggo le liste ricevute da ServerV
            ObjectInputStream objectInputStream = new ObjectInputStream(socketServerV.getInputStream());
            Map<String,Boolean> greenpassValidi = (Map<String, Boolean>) objectInputStream.readObject();
            Map<String,Boolean> greenpassScaduti = (Map<String, Boolean>) objectInputStream.readObject();
            System.out.println("Sto ricevendo le liste..");
            if(greenpassScaduti.isEmpty()){
                if(greenpassValidi.isEmpty()){
                    System.out.println("Tessera non presente nel registro!!");
                } else {
                    greenpassValidi.remove(args[0]);
                    greenpassScaduti.put(args[0],false);
                }
            } else {
                if (greenpassScaduti.get(args[0]).equals(false)){
                    greenpassScaduti.remove(args[0]);
                    greenpassValidi.put(args[0],true);
                }
            }
            System.out.println(List.of(greenpassValidi).toString());
            System.out.println(List.of(greenpassScaduti).toString());

            //rimando le liste con i valori aggiornati al serverV
            ObjectOutputStream objectOutputStream = new ObjectOutputStream(socketServerV.getOutputStream());
            synchronized (SharedLock.lock) {
                objectOutputStream.writeObject(greenpassValidi);
                objectOutputStream.writeObject(greenpassScaduti);
                objectOutputStream.flush();
            }
            System.out.println("Ho cambiato gli opportuni valori e sto rimandando a ServerV le liste aggiornate...");
            socketServerV.close();
        } catch (IOException | ClassNotFoundException e) {
            throw new RuntimeException(e);
        }
    }
}

