public class SharedLock {
    public static final Object lock = new Object();
}
